/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

#include ".\assist\getlinestr.h"
#include ".\assist\analysis.h"
#include ".\assist\str_to_lower.h"
#include ".\assist\flush_stdin.h"
#include ".\assist\flush_stdout.h"
#include ".\assist\str_or_int_switch.h"

