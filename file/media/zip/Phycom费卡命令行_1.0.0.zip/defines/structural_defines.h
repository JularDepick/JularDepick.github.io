#define ruif if
#define elif else if
#define ruse else

#define _varname first
#define _vardata second
#define _vartype second

#define vartype_int 0x0000
#define vartype_float 0x0001
#define vartype_char 0x0002
#define vartype_text 0x0003
