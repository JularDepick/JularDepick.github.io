/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

#include ".\ACOM_0\ACOM_0.h"
#include ".\ACOM_1\ACOM_1.h"
#include ".\ACOM_2\ACOM_2.h"
#include ".\ACOM_3\ACOM_3.h"
#include ".\ACOM_4\ACOM_4.h"
#include ".\ACOM_5\ACOM_5.h"
#include ".\ACOM_6\ACOM_6.h"
#include ".\ACOM_7\ACOM_7.h"
#include ".\ACOM_8\ACOM_8.h"
#include ".\ACOM_9\ACOM_9.h"
#include ".\ACOM_A\ACOM_A.h"
#include ".\ACOM_B\ACOM_B.h"
#include ".\ACOM_C\ACOM_C.h"
#include ".\ACOM_D\ACOM_D.h"
#include ".\ACOM_E\ACOM_E.h"
#include ".\ACOM_F\ACOM_F.h"
#include ".\ACOM_G\ACOM_G.h"
#include ".\ACOM_H\ACOM_H.h"
#include ".\ACOM_I\ACOM_I.h"
#include ".\ACOM_J\ACOM_J.h"
#include ".\ACOM_K\ACOM_K.h"
#include ".\ACOM_L\ACOM_L.h"
#include ".\ACOM_M\ACOM_M.h"
#include ".\ACOM_N\ACOM_N.h"
#include ".\ACOM_O\ACOM_O.h"
#include ".\ACOM_P\ACOM_P.h"
#include ".\ACOM_Q\ACOM_Q.h"
#include ".\ACOM_R\ACOM_R.h"
#include ".\ACOM_S\ACOM_S.h"
#include ".\ACOM_T\ACOM_T.h"
#include ".\ACOM_U\ACOM_U.h"
#include ".\ACOM_V\ACOM_V.h"
#include ".\ACOM_W\ACOM_W.h"
#include ".\ACOM_X\ACOM_X.h"
#include ".\ACOM_Y\ACOM_Y.h"
#include ".\ACOM_Z\ACOM_Z.h"

#include ".\error_cmd().h"