/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

string seek_all_avars() {
	string respond = "\n�����б�:\n";

	//����int
	for (int idx = 0; idx < int(AVARS_SHORT.size()); idx++) {
		respond += "  int ";
		respond += AVARS_SHORT[idx]._varname;
		respond += "=";
		respond += int_to_str(AVARS_SHORT[idx]._vardata);
		respond += ";\n";
	}
	for (int idx = 0; idx < int(AVARS_INT.size()); idx++) {
		respond += "  int ";
		respond += AVARS_INT[idx]._varname;
		respond += "=";
		respond += int_to_str(AVARS_INT[idx]._vardata);
		respond += ";\n";
	}
	for (int idx = 0; idx < int(AVARS_LONG.size()); idx++) {
		respond += "  int ";
		respond += AVARS_LONG[idx]._varname;
		respond += "=";
		respond += int_to_str(AVARS_LONG[idx]._vardata);
		respond += ";\n";
	}
	for (int idx = 0; idx < int(AVARS_LONGLONG.size()); idx++) {
		respond += "  int ";
		respond += AVARS_LONGLONG[idx]._varname;
		respond += "=";
		respond += int_to_str(AVARS_LONGLONG[idx]._vardata);
		respond += ";\n";
	}
	for (int idx = 0; idx < int(AVARS_STRONGINT.size()); idx++) {
		respond += "  int ";
		respond += AVARS_STRONGINT[idx]._varname;
		respond += "=";
		respond += (AVARS_STRONGINT[idx]._vardata).Get_with_str();
		respond += ";\n";
	}

	//����float
	//����char
	//����text

	return ((respond.size() <= 12) ? (respond + "��\n") : (respond));
}

string seek_the_avar(string varname) {

	if (!check_varname(varname)) {
		return ("�Ƿ������� \'" + varname + "\' !\n");
	}

	if (!check_var(varname)) {
		return ("�Ҳ������� \'" + varname + "\' !\n");
	}

	string respond = ("�ҵ�����!\n" + varname + "=");

	//����int
	for (int idx = 0; idx < int(AVARS_SHORT.size()); idx++) {
		if (AVARS_SHORT[idx]._varname == varname) {
			respond += (int_to_str(AVARS_SHORT[idx]._vardata) + "\n");
			return respond;
		}
	}
	for (int idx = 0; idx < int(AVARS_INT.size()); idx++) {
		if (AVARS_INT[idx]._varname == varname) {
			respond += (int_to_str(AVARS_INT[idx]._vardata) + "\n");
			return respond;
		}
	}
	for (int idx = 0; idx < int(AVARS_LONG.size()); idx++) {
		if (AVARS_LONG[idx]._varname == varname) {
			respond += (int_to_str(AVARS_LONG[idx]._vardata) + "\n");
			return respond;
		}
	}
	for (int idx = 0; idx < int(AVARS_LONGLONG.size()); idx++) {
		if (AVARS_LONGLONG[idx]._varname == varname) {
			respond += (int_to_str(AVARS_LONGLONG[idx]._vardata) + "\n");
			return respond;
		}
	}
	for (int idx = 0; idx < int(AVARS_STRONGINT.size()); idx++) {
		if (AVARS_STRONGINT[idx]._varname == varname) {
			respond += ((AVARS_STRONGINT[idx]._vardata).Get_with_str() + "\n");
			return respond;
		}
	}

	//����float
	//����char
	//����text

	return ("�Ҳ������� \'" + varname + "\' !\n");
}

string com1000_seekvar(string varname) {
	if (varname.empty()) {
		return seek_all_avars();
	} else {
		return seek_the_avar(varname);
	}
}