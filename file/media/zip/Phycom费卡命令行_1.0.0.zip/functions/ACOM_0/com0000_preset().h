/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

const string com0000_presetstr =
    "\
<Phycom.pym>\n\
  -Version:    1.0.0\n\
  -Copyright:  1724834368@qq.com\n\
  -Website:    https://JularDepick.github.io/\n\
  -���� \'help\' ��Ѱ�����!\n\n\
";

string com0000_preset() {
	SetConsoleTitleA("Phycom.pym");

	//���ڴ�С���������޸�
	system("mode con: cols=100 lines=25");
	SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE), {100, 400});

	system("color 0A");
	system("cls");
	cout << com0000_presetstr;
	return "";
}