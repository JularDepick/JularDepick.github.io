/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

string com0zzz_exit() {
	system("cls");
	cout << Phycom_head << Exit_str << endl;
	Sleep(1000);
	return "";
}