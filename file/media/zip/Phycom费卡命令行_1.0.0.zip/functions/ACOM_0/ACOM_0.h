/* Phycom.pym
* Copyright: 1724834368@qq.com
*/

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

#include ".\com0000_preset().h"
#include ".\com0001_wincmd().h"
#include ".\com0002_help().h"
#include ".\com0003_phycom().h"

#include ".\com0zzz_exit().h"
