/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

#include ".\defines\commands.h"
#include ".\defines\structural_defines.h"
#include ".\defines\typename_defines.h"