#include <bits/stdc++.h>
using namespace std;

bool check_varname(string prename) {
	if (prename.size() > 1024) {
		//����������
		return 0;
	}
	regex restr("(([a-zA-Z]|[_])+([a-zA-Z0-9]|[_])*)");
	return (regex_match(prename, restr));
}

int main() {
	for (;;) {
		string s;
		cin >> s;
		cout << endl << check_varname(s) << endl;
	}
}