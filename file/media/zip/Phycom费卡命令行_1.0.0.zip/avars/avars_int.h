/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

vector<pair<string, short>> AVARS_SHORT = {};

vector<pair<string, int>> AVARS_INT = {};

vector<pair<string, long>> AVARS_LONG = {};

vector<pair<string, long long>> AVARS_LONGLONG = {};

class Strongint {
	public:
		Strongint() {
			Value = "0";
		}
		Strongint(short val) {
			Value = int_to_str(val);
		}
		Strongint(int val) {
			Value = int_to_str(val);
		}
		Strongint(long val) {
			Value = int_to_str(val);
		}
		Strongint(long long val) {
			Value = int_to_str(val);
		}

		long long int Get_with_int() {
			return str_to_int(Value);
		}
		string Get_with_str() {
			return Value;
		}
	private:
		string Value = "";
};

vector<pair<string, Strongint>> AVARS_STRONGINT = {};
